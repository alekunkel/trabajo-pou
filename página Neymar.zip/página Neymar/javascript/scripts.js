function correr() {
    // Lógica para correr
  
    // Obtener el valor actual del sueño
    var valorSueno = parseInt(document.getElementById("sueño").textContent);
  
    // Actualizar el valor del sueño
    valorSueno = Math.min(100, valorSueno + 25);
    document.getElementById("sueño").textContent = valorSueno;
  
    updateNeymarTriste(valorSueno);
  }
  
  function dormir() {
    // Lógica para dormir
  
    // Obtener el valor actual del sueño
    var valorSueno = parseInt(document.getElementById("sueño").textContent);
  
    // Actualizar el valor del sueño
    valorSueno = Math.max(0, valorSueno - 25);
    document.getElementById("sueño").textContent = valorSueno;
  
    updateNeymarTriste(valorSueno);
  }
  
  function updateNeymarTriste(sueño) {
    var neymarTristeContainer = document.getElementById("neymarTristeContainer");
  
    if (sueño === 100) {
      neymarTristeContainer.style.display = "block"; // Mostrar imagen triste
    } else {
      neymarTristeContainer.style.display = "none"; // Ocultar imagen triste
    }
  }
  